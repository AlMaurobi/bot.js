module.exports = {
    client: {
        token: "MTUwNTIyNDg4NTU0OTY2MjM2OA.G2I1Li.wQ_-sgdZDsSG-U9SNt2koX_lO2n5uQKaDzUaKQ",
        id: "1505224885549662368",
        guild: "1330099926411247677",
        version: "5.6",
    },
    icon: {
        thumbnail: "https://cdn.discordapp.com/attachments/1336640285995962440/1367390194176888892/image.png?ex=6820ef1b&is=681f9d9b&hm=d3325fff967dd8dc227518593b8322df6b1b4b6cc16e9c1007d21a74f8d51e9a&",
        image: "https://media.discordapp.net/attachments/1489321615987576852/1504509262376996955/20260514_224103.png?ex=6a09e1f0&is=6a089070&hm=e314ddec40cae5cd0a17c85d389c1bfdc5b5df4af81650a5accba64d813a57e4&=&format=webp&quality=lossless&width=315&height=315).",
    },
    mysql: {
        connectionLimit: 5,
        host: "db3.sampryzen.com",
        user: "u2000_Q0dkJmnYhQ",
        password: "wv^l.Kpv=4zQ5h5TReWA5=CX",
        database: "s2000_kahayangan_samp",
    },
    verifrole: {
        warga: '1404028015331119154'
    },
    idrole: {
        ucp: "1404028015331119154",
    },
    channel: {
        registerLogs: "1403962300775268422",
        allowedChannelslink: ['1403962300775268422'],
    },
    handler: {
        prefix: "!",
        deploy: true,
        commands: {
            prefix: true,
            slash: true,
            user: true,
            message: true,
        }
    },
    users: {
        developers: ["1055388711912734750"],
        ownerId: ["643109939824427009"],
    },
    development: {
        enabled: false,
        guild: "1330099926411247677",
    },
    servers: {
        name: "Kahayangan Roleplay",
    },
    messageSettings: {
        ownerMessage: "Pengembang bot memiliki satu-satunya izin untuk menggunakan perintah ini.",
        developerMessage: "Anda tidak berwenang untuk menggunakan perintah ini.",
        cooldownMessage: "Pelan-pelan sobat! Anda terlalu cepat untuk menggunakan perintah ini ({cooldown}s).",
        globalCooldownMessage: "Pelan-pelan sobat! Perintah ini berada pada cooldown global ({cooldown}s).",
        notHasPermissionMessage: "Anda tidak memiliki izin untuk menggunakan perintah ini.",
        notHasPermissionComponent: "Anda tidak memiliki izin untuk menggunakan komponen ini.",
        missingDevIDsMessage: "Ini adalah perintah khusus pengembang, tetapi tidak dapat dijalankan karena ID pengguna tidak ada di file konfigurasi."
    }
};
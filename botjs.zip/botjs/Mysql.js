const MySQL = require("mysql");
const config = require('./config');

let MysqlMortal = MySQL.createPool(config.mysql)
MysqlMortal.getConnection((err, connect) => {
    if(connect) return console.log("\x1b[36m[DATABASE]: \x1b[0mMENGHUBUNGKAN MYSQL BERHASIL");
    console.log("\x1b[36m[DATABASE]: \x1b[0mMenghubungkan MYSQL GAGAL | SILAHKAN CEK ERROR DAN COBA LAGI")
})

module.exports = MysqlMortal;
const {
    ButtonInteraction,
    ModalBuilder,
    ActionRowBuilder,
    TextInputBuilder,
    TextInputStyle
} = require('discord.js');
const ExtendedClient = require('../../class/ExtendedClient');
const ms = require("ms");
const MysqlMortal = require('../../../Mysql');
const { IntSucces, IntError } = require('../../../functions');

const timeAccount = ms("0 days");

module.exports = {
    customId: 'button-register',
    /**
     * 
     * @param {ExtendedClient} client 
     * @param {ButtonInteraction} interaction 
     */
    run: async (client, interaction) => {
        const userid = interaction.user.id;
        const createdAt = new Date(interaction.user.createdAt).getTime();
        const detectDays = Date.now() - createdAt;

        if (detectDays < timeAccount) {
            return IntError(interaction, "Umur akun anda tidak mencukupi untuk mendaftar Akun UCP di server Crubel Country Roleplay!");
        }

        // Periksa apakah pengguna sudah terdaftar
        MysqlMortal.query('SELECT * FROM playerucp WHERE DiscordID = ?', [userid], async (err, row) => {
            if (err) {
                console.error('Database query error:', err);
                return IntError(interaction, 'Terjadi kesalahan pada database.');
            }

            if (row.length < 1) {
                const modal = new ModalBuilder()
                    .setTitle('Pendaftaran User Control Panel')
                    .setCustomId('modal-register')
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setLabel('Isi Nama UCP Anda Di Bawah Ini')
                                .setCustomId('reg-name')
                                .setPlaceholder('Nama User Control Panel Anda')
                                .setStyle(TextInputStyle.Short)
                                .setMinLength(4)
                                .setMaxLength(15)
                                .setRequired(true)
                        )
                    );

                await interaction.showModal(modal);
            } else {
                return IntError(interaction, `**Register UCP | Crubel Country Roleplay**\n:x: Error!\n\n> Anda sudah pernah mendaftar dengan nama **_${row[0].Username}_** dan tidak bisa lagi mengambil tiket\n\n**Crubel Country Roleplay**`);
            }
        });
    }
};

const client = new ExtendedClient();
client.on('interactionCreate', async interaction => {
    if (interaction.isModalSubmit() && interaction.customId === 'modal-register') {
        const userid = interaction.user.id;
        const ucp = interaction.fields.getTextInputValue('reg-name');

        // Validasi input nama UCP
        if (ucp.includes('_')) return IntError(interaction, 'Nama akun User Control Panel Tidak boleh disertai dengan Simbol "_"');
        if (ucp.includes(' ')) return IntError(interaction, 'Nama akun User Control Panel Tidak boleh disertai dengan Spasi');
        if (!/^[a-z]+$/i.test(ucp)) return IntError(interaction, 'Nama akun User Control Panel Tidak boleh disertai dengan simbol ataupun angka!');

        try {
            const [userByDiscordID] = await MysqlMortal.promise().query('SELECT * FROM playerucp WHERE DiscordID = ?', [userid]);
            if (userByDiscordID.length > 0) {
                return IntError(interaction, `Anda sudah terdaftar dengan Discord ID ini. Nama akun UCP Anda adalah "${userByDiscordID[0].Username}".`);
            }

            const [userByUsername] = await MysqlMortal.promise().query('SELECT * FROM playerucp WHERE ucp = ?', [ucp]);
            if (userByUsername.length > 0) {
                return IntError(interaction, 'Maaf nama akun yang anda input telah terdaftar, Silahkan mencoba nama akun yang lain!');
            } else {
                const registerDate = Math.floor(Date.now() / 1000);

                await MysqlMortal.promise().query(
                    `INSERT INTO playerucp (ucp, DiscordID) VALUES (?, ?)`,
                    [ucp, userid]
                );

                IntSucces(interaction, 'Selamat akun User Control Panel Anda telah berhasil didaftarkan!');
            }
        } catch (error) {
            console.error('Unexpected error:', error);
            return IntError(interaction, 'Terjadi kesalahan yang tidak terduga.');
        }
    }
});

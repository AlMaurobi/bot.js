const { ButtonInteraction, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const mysql = require('mysql2');
const config = require('../../../config');
const { IntSucces, IntError } = require('../../../functions');

const MysqlMortal = mysql.createPool({
    host: config.mysql.host,
    user: config.mysql.user,
    password: config.mysql.password,
    database: config.mysql.database,
}).promise()



module.exports = {
    customId: 'modal-register',
    /**
     * @param {ExtendedClient} client 
     * @param {ButtonInteraction} interaction 
     */
    run: async (client, interaction) => {

        try {
            await interaction.deferReply({ ephemeral: true });
            const userid = interaction.user.id;
            const inputName = interaction.fields.getTextInputValue('reg-name');
            const randCode = Math.floor(100000 + Math.random() * 900000); 

            if (inputName.includes("_")) return IntError(interaction, 'The User Control Panel account name cannot contain the "_" symbol.');
            if (inputName.includes(" ")) return IntError(interaction, 'The User Control Panel account name cannot contain spaces.');
            if (!/^[a-zA-Z]+$/.test(inputName)) return IntError(interaction, 'The User Control Panel account name can only contain letters!');

            const [existingUser] = await MysqlMortal.query('SELECT * FROM playerucp WHERE ucp = ?', [inputName]);

            if (existingUser.length > 0) {
                return IntError(interaction, 'Sorry, the account name you entered is already registered. Please try a different account name.');
            }

            const registerDate = Math.floor(Date.now() / 1000);
            await MysqlMortal.query(
                'INSERT INTO playerucp (ucp, password, verifycode, DiscordID) VALUES (?, "", ?, ?)',
                [inputName, randCode, userid]
            );


            const msgEmbed = new EmbedBuilder()
                .setAuthor({ name: 'UCP TICKET REGISTRATION | Crubel Country Roleplay', iconURL: config.icon.thumbnail })
                .setDescription(`Dear **${inputName}**,\n\nTicket registration successful. Use the UCP to log into the server! Join the server and enter the verification code below!\n\n**UCP**: ${inputName}\n\n**Verification Code**: ${randCode}\n\n**Registration Time**: <t:${Math.round(Date.now() / 1000)}:R>`)
                .setColor('Green')
                .setImage(config.icon.image)
                .setFooter({ text: interaction.guild.name })
                .setTimestamp();

            await interaction.user.send({ embeds: [msgEmbed] });
            console.log(`[BOT]: User (${interaction.user.tag}) successfully registered a UCP account with name (${inputName}) and pin (${randCode})`);

            try {
                const role = await interaction.guild.roles.cache.get(config.idrole.ucp);
                const guildMember = await interaction.guild.members.fetch(interaction.member.id);
                await guildMember.roles.add(role);
                await guildMember.setNickname(`Warga | ${inputName}`);
            } catch (error) {
                console.error('Error assigning role or updating nickname:', error);
            }
            const successEmbed = new EmbedBuilder()
                .setTitle("UCP TICKET REGISTRATION | Crubel Country Roleplay")
                .setDescription(`:white_check_mark: **Success!**\n\nUCP account registration successful, please check your DM from Crubel Country Roleplay!`)
                .setColor('Green') 
                .setFooter({ text: '~wispuli #ontop~' });

            await interaction.followUp({ embeds: [successEmbed], ephemeral: true });


            const logChannelId = config.channel.registerLogs;
            const logChannel = client.channels.cache.get(logChannelId);

            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle("New UCP Registration")
                    .setColor('Blue')
                    .addFields(
                        { name: "UCP Name", value: inputName, inline: true },
                        { name: "Discord", value: interaction.user.tag, inline: true },
                        { name: "Discord ID", value: userid, inline: true },
                        { name: "Register Date", value: `<t:${registerDate}:R>`, inline: true }
                    )
                    .setFooter({ text: interaction.guild.name })
                    .setTimestamp();

                await logChannel.send({ embeds: [logEmbed] });
            } else {
            }
        } catch (error) {
            console.error('Unexpected error:', error);
            if (!interaction.replied && !interaction.deferred) {
                await IntError(interaction, 'An unexpected error occurred.');
            }
        }
    }
};
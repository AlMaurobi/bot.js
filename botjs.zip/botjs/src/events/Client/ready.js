const { EmbedBuilder } = require('discord.js');
const ExtendedClient = require('../../class/ExtendedClient');
const config = require('../../../config');


module.exports = {
    event: 'ready',
    
    /**
     * @param {ExtendedClient} client
     */
    run: async (client) => {
        console.log(`[BOT]: Bot is online as ${client.user.tag}`);

        const channelId = '1334053646119473202';

        client.guilds.cache.forEach(guild => {
            const targetChannel = guild.channels.cache.get(channelId);

            if (targetChannel && targetChannel.isTextBased() && targetChannel.permissionsFor(guild.members.me).has('SendMessages')) {
                const embed = new EmbedBuilder()
                    .setColor(0x0099ff)
                    .setTitle('Bot Online!')
                    .setDescription('Bot is now online and ready to serve! Here is some information about this bot:')
                    .addFields(
                        { name: 'Bot Name', value: client.user.username, inline: true },
                        { name: 'Developed by', value: 'Gyu Chaves', inline: true },
                        { name: 'Prefix', value: '!', inline: true },
                        { name: 'Version', value: `${config.client.version}`, inline: true }
                    )
                    .setFooter({ text: 'Thank you for using this bot!', iconURL: client.user.displayAvatarURL() })
                    .setTimestamp();

                targetChannel.send({ embeds: [embed] }).catch(error => {
                    console.error(`Gagal mengirim pesan ke channel dengan ID ${channelId} di ${guild.name}:`, error);
                });
            } else {
                console.error(`Channel dengan ID ${channelId} tidak ditemukan atau bot tidak memiliki izin mengirim pesan di ${guild.name}.`);
            }
        });
    }
};

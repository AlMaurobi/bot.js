const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const ExtendedClient = require('../../../class/ExtendedClient');
const { time } = require('../../../../functions');
const config = require('../../../../config');

module.exports = {
    structure: new SlashCommandBuilder()
        .setName('handleregister')
        .setDescription('Menampilkan Panel Registrasi UCP'),
    options: {
        ownerOnly: true,
        developers: true
    },
    /**
     * @param {ExtendedClient} client 
     * @param {ChatInputCommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        
        const msgEmbed = new EmbedBuilder()
            .setTitle('Crubel Country Roleplay | Control Panel')
            .setThumbnail(config.icon.thumbnail)
            .setImage(config.icon.image)
            .setDescription(`:information_source: Di channel ini, kamu bisa mengatur akun UCP kamu. Berikut beberapa fitur yang tersedia:\n\n**__📮 Create UCP__**\n Tombol ini digunakan untuk mengambil Tiket (membuat akun UCP). Sebelum bermain di Crubel Country Roleplay, kamu harus memiliki Tiket ini.\n\n**__🕵️ Cek UCP__**\n Kamu bisa melihat status Tiketmu, apakah sudah terverifikasi atau belum. Kamu juga bisa melihat kode verifikasi jika belum menerima DM dari BOT.\n\n**__♻️ Reff UCP__**\n Jika sudah mengambil Tiket tetapi tidak mendapatkan role <@&1292799486090940457>, gunakan tombol ini. Juga gunakan ini jika kamu keluar dari Discord Server dan ingin kembali bermain, untuk mengambil kembali role <@&1292799486090940457>!`)
            .setColor('Blue')
            .setFooter({ text: interaction.guild.name, iconURL: config.icon.thumbnail });

        const buttons = new ActionRowBuilder()
            .addComponents(

                new ButtonBuilder()
                    .setLabel('Registrasi UCP')
                    .setStyle('Success')
                    .setCustomId('button-register')
                    .setEmoji("✅"),

                new ButtonBuilder()
                    .setLabel('Cek UCP')
                    .setStyle('Primary')
                    .setCustomId('button-resendcode')
                    .setEmoji("🕵️"),

                new ButtonBuilder()
                    .setLabel('Reff Role UCP')
                    .setStyle('Success')
                    .setCustomId('button-reffrole')
                    .setEmoji("♻️")

            );

        await interaction.channel.send({ embeds: [msgEmbed], components: [buttons] });
        return interaction.reply({ content: "Sukses Membuat Embed HandleRegister", ephemeral: true });
    }
};

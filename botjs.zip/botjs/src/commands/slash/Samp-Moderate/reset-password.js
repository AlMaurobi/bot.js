const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const ExtendedClient = require('../../../class/ExtendedClient');
const { time } = require('../../../../functions');
const config = require('../../../../config');

module.exports = {
    structure: new SlashCommandBuilder()
        .setName('reset-pass')
        .setDescription('Menampilkan Panel Reset Password'),
    options: {
        ownerOnly: true,
        developers: true
    },
    /**
     * @param {ExtendedClient} client 
     * @param {ChatInputCommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        
        const msgEmbed = new EmbedBuilder()
            .setTitle('Crubel Country Roleplay | Control Panel')
            .setThumbnail(config.icon.thumbnail)
            .setImage(config.icon.image)
            .setDescription(`Tekan Tombol Dibawah Ini Untuk Mereset Akun UCP Anda\n\n Dan Anda akan Otomatis Mendapatkan Pesan Dari bot Berisikan Kode UCP Baru Lalu Masuk Ke Game \n\n Dan Buat ulang Password Anda`)
            .setColor('Blue')
            .setFooter({ text: interaction.guild.name, iconURL: config.icon.thumbnail });

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('Reset Password')
                    .setStyle('Danger')
                    .setCustomId('button-reset')
                    .setEmoji("⚠️"),

            );

        await interaction.channel.send({ embeds: [msgEmbed], components: [buttons] });
        return interaction.reply({ content: "Sukses Membuat Embed HandleRegister", ephemeral: true });
    }
};

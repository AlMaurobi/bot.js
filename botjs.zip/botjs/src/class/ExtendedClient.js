const { Client, Partials, Collection, GatewayIntentBits } = require("discord.js");
const config = require("../../config");
const commands = require("../handlers/commands");
const events = require("../handlers/events");
const deploy = require("../handlers/deploy");
const components = require("../handlers/components");

module.exports = class ExtendedClient extends Client {
    constructor() {
        super({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent,
            ],
            partials: [
                Partials.Channel,
                Partials.GuildMember,
                Partials.Message,
                Partials.Reaction,
                Partials.User,
                Partials.ThreadMember,
            ],
            presence: {
                activities: [
                    {
                        name: "Gyu Development",
                        type: 4, // Custom Status
                        state: config.servers.name,
                    },
                ],
            },
        });

        // Initialize collections
        this.collection = {
            interactioncommands: new Collection(),
            prefixcommands: new Collection(),
            aliases: new Collection(),
            components: {
                buttons: new Collection(),
                selects: new Collection(),
                modals: new Collection(),
                autocomplete: new Collection(),
            },
        };

        this.applicationcommandsArray = [];
        this.linkViolations = new Map();
        this.allowedChannels = config.channel.allowedChannels || [];
    }

    // Start the bot
    async start() {
        const currentVersion = "5.6";
        const requiredVersion = config.client.version;

        // Verify bot version
        if (currentVersion !== requiredVersion) {
            console.error(
                `[ERROR] Bot version mismatch: required ${requiredVersion}, found ${currentVersion}.`
            );
            process.exit(1);
        }

        // Load commands, events, and components
        commands(this);
        events(this);
        components(this);

        // Log in to Discord
        await this.login(config.client.token);

        // Deploy commands if needed
        if (config.handler.deploy) {
            deploy(this, config);
        }

        // Handle messageCreate event
        this.on("messageCreate", async (message) => {
            if (message.author.bot || !message.guild) return;

            const linkRegex = /https?:\/\/[^\s]+/;
            const isLink = linkRegex.test(message.content);
            const isInAllowedChannel = this.allowedChannels.includes(message.channel.id);

            if (isLink && !isInAllowedChannel) {
                const userId = message.author.id;
                const violation = this.linkViolations.get(userId) || { count: 0, lastMessageTime: 0 };

                const now = Date.now();
                const timeSinceLastMessage = now - violation.lastMessageTime;

                if (timeSinceLastMessage < 5000) {
                    violation.count += 1;
                } else {
                    violation.count = 1;
                }

                violation.lastMessageTime = now;

                if (violation.count >= 3) {
                    try {
                        const member = message.guild.members.cache.get(userId);
                        if (member) {
                            await member.timeout(
                                604800000, // 1 week in milliseconds
                                "SPAM LINK TIMEOUT 1 WEEK"
                            );
                            message.channel.send(
                                `${message.author} has been timed out for spamming links.`
                            );
                        }
                    } catch (error) {
                        console.error("[WARNING] Failed to timeout user:", error);
                    }
                    return;
                }

                this.linkViolations.set(userId, violation);
            }
        });
    }
};
